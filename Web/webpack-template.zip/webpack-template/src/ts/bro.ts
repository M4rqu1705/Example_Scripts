exports.BRO = function (greetings: string) {
    return `${greetings}, bro`;
}