import "../scss/styles.scss";

const { BRO } = require("./bro.ts");

console.log(BRO("Dude"));
console.log("-------------------------------------------")