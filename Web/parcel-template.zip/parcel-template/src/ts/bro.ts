const bro = function (message: string) {
    return `${message}, bro`;
}

export { bro }