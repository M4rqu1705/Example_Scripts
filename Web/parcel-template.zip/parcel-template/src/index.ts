import './scss/styles.scss'

import { bro } from './ts/bro';

console.log(bro("Hello World"));